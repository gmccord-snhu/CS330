﻿///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes(); 

    // Define table properties
    m_tablePos = glm::vec3(0.0f, 3.0f, 0.0f);
    m_tableScale = glm::vec3(14.0f, 0.5f, 8.0f);
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width = 0;
    int height = 0;
    int colorChannels = 0;
    GLuint textureID = 0;

    // indicate to always flip images vertically when loaded
    stbi_set_flip_vertically_on_load(true);

    // try to parse the image data from the specified image file
    unsigned char* image = stbi_load(
        filename,
        &width,
        &height,
        &colorChannels,
        0);

    // if the image was successfully read from the image file
    if (image)
    {
        std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        // if the loaded image is in RGB format
        if (colorChannels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        // if the loaded image is in RGBA format - it supports transparency
        else if (colorChannels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
            return false;
        }

        // generate the texture mipmaps for mapping textures to lower resolutions
        glGenerateMipmap(GL_TEXTURE_2D);

        // free the image data from local memory
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        // register the loaded texture and associate it with the special tag string
        m_textureIDs[m_loadedTextures].ID = textureID;
        m_textureIDs[m_loadedTextures].tag = tag;
        m_loadedTextures++;

        return true;
    }

    std::cout << "Could not load image:" << filename << std::endl;

    // Error loading the image
    return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glGenTextures(1, &m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    int textureID = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && (bFound == false))
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureID = m_textureIDs[index].ID;
            bFound = true;
        }
        else
            index++;
    }

    return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    int textureSlot = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && (bFound == false))
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureSlot = index;
            bFound = true;
        }
        else
            index++;
    }

    return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    if (m_objectMaterials.size() == 0)
    {
        return(false);
    }

    int index = 0;
    bool bFound = false;
    while ((index < m_objectMaterials.size()) && (bFound == false))
    {
        if (m_objectMaterials[index].tag.compare(tag) == 0)
        {
            bFound = true;
            material.diffuseColor = m_objectMaterials[index].diffuseColor;
            material.specularColor = m_objectMaterials[index].specularColor;
            material.shininess = m_objectMaterials[index].shininess;
        }
        else
        {
            index++;
        }
    }

    return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    // variables for this method
    glm::mat4 modelView;
    glm::mat4 scale;
    glm::mat4 rotationX;
    glm::mat4 rotationY;
    glm::mat4 rotationZ;
    glm::mat4 translation;

    // set the scale value in the transform buffer
    scale = glm::scale(scaleXYZ);
    // set the rotation values in the transform buffer
    rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    // set the translation value in the transform buffer
    translation = glm::translate(positionXYZ);

    modelView = translation * rotationZ * rotationY * rotationX * scale;

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
    }
}

/**
 * @brief Sets the specified RGBA color in the shader for the next draw command.
 *
 * This updates the shader's color uniform to affect the appearance of
 * subsequent objects or materials rendered.
 *
 * @param redColorValue The red component of the color (0.0 to 1.0).
 * @param greenColorValue The green component of the color (0.0 to 1.0).
 * @param blueColorValue The blue component of the color (0.0 to 1.0).
 * @param alphaValue The alpha (transparency) component of the color (0.0 to 1.0).
 */
void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    // variables for this method
    glm::vec4 currentColor;

    currentColor.r = redColorValue;
    currentColor.g = greenColorValue;
    currentColor.b = blueColorValue;
    currentColor.a = alphaValue;

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  Assigns a texture to the shader using the provided texture ID.
 *  This method ensures that the shader references the correct
 *  texture data for rendering, allowing materials to display
 *  detailed surface appearances.
 *
 *  A shader is a small program that runs on the GPU, controlling
 *  how objects are drawn on the screen. It processes lighting,
 *  colors, and textures to create realistic or stylized visual
 *  effects in 3D graphics.
 ***********************************************************/
void SceneManager::SetShaderTexture(
    std::string textureTag)
{
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, true);

        int textureID = -1;

        // Pull from memory by name
        textureID = FindTextureSlot(textureTag);

        m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
    }
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  Adjusts the UV scaling factors for texture mapping in the shader.
 *  This function updates the "UVscale" uniform with the given
 *  horizontal (u) and vertical (v) scale values, allowing textures
 *  to be stretched, compressed, or tiled across a 3D surface.
 *
 *  By modifying the UV scale dynamically, this method provides
 *  greater control over texture appearance without altering the
 *  original texture, enabling flexible visual effects at runtime.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
    }
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  Passes material properties to the shader for rendering.
 *  This method ensures that the shader receives the correct
 *  values for lighting, texture, and other visual effects.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
    std::string materialTag)
{
    if (m_objectMaterials.size() > 0)
    {
        OBJECT_MATERIAL material;
        bool bReturn = false;

        bReturn = FindMaterial(materialTag, material);
        if (bReturn == true)
        {
            m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
            m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
            m_pShaderManager->setFloatValue("material.shininess", material.shininess);
        }
    }
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
    // load the texture image files for the textures applied
    // to objects in the 3D scene
    LoadSceneTextures();
    // define the materials that will be used for the objects
    // in the 3D scene
    DefineObjectMaterials();

    // only one instance of a particular mesh needs to be
    // loaded in memory no matter how many times it is drawn
    // in the rendered 3D scene

    /// Load meshes
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadTorusMesh();
    m_basicMeshes->LoadTaperedCylinderMesh();
    m_basicMeshes->LoadConeMesh();
    m_basicMeshes->LoadSphereMesh();

    // add and define the light sources for the scene
    AddSceneLights();
}

void SceneManager::RenderScene()
{
    // Define table properties
    glm::vec3 tablePos = glm::vec3(0.0f, 3.0f, 0.0f);
    glm::vec3 tableScale = glm::vec3(14.0f, 0.5f, 8.0f);

    // Moon light box at window, enable for debugging
    //DrawLightBox(0.0f, 12.0f, -12.0f);

    // Draw the table
    DrawTable(tablePos, tableScale);
    DrawFloor();
    DrawWall();

    DrawTableEdges(tablePos, tableScale);

    // Draw test tube rack components
    DrawTubeRack_Base(tablePos, tableScale.y);
    DrawTubeRack_Top(tablePos, tableScale.y);
    DrawTubeRack_RightVertical(tablePos, tableScale.y);
    DrawTubeRack_LeftVertical(tablePos, tableScale.y);

    // Define test tube rack parameters
    int numTestTubes = 7; // Number of test tubes
    float startXOffset = -1.9f; // Starting X position relative to the table
    float spacing = 0.5f;  // Distance between test tubes along the rack
    float rackAngle = glm::radians(135.0f); // Angle of the rack in radians

    // Draw test tubes along the angled rack
    DrawTestTubes(tablePos, tableScale.y, numTestTubes, startXOffset, spacing, rackAngle);

    DrawCandle(tablePos, tableScale.y);

    DrawBeaker(tablePos, tableScale.y);

    DrawInkwell(tablePos, tableScale.y);

    DrawPapers(tablePos, tableScale.y);

    DrawWineGlass(tablePos, tableScale.y);

    DrawPen(tablePos, tableScale.y);

    DrawWaterBowl();

    SetFlickeringLights();
}

/***********************************************************
 *  DrawTestTubes()
 *
 *  This function positions and draws multiple test tubes
 *  along an angled rack using trigonometry. The X position
 *  of each test tube is calculated with cosine, and the Z
 *  position is calculated with sine, based on the specified
 *  rack angle and spacing. Each test tube is positioned
 *  incrementally along the rack.
 *
 *  Parameters:
 *    - tablePos (glm::vec3): Position of the table in world space.
 *    - tableHeight (float): Height of the table, used to position
 *                           test tubes correctly above the table.
 *    - numTestTubes (int): The number of test tubes to be drawn.
 *    - startXOffset (float): Starting X position for the first test tube
 *                             relative to the table.
 *    - spacing (float): The distance between each test tube along the rack.
 *    - rackAngle (float): The angle of the rack in radians, determining
 *                          the direction of the test tubes.
 *
 *  The function calculates the correct position for each test tube using
 *  trigonometric functions (cosine and sine) to distribute the test tubes
 *  along the angled rack and calls DrawTestTube() to render each tube.
 *
 ***********************************************************/
void SceneManager::DrawTestTubes(glm::vec3 tablePos, float tableHeight, int numTestTubes, float startXOffset, float spacing, float rackAngle)
{
    // Loop through the number of test tubes and calculate their positions
    for (int i = 0; i < numTestTubes; i++)
    {
        // Calculate the X and Z offsets using trigonometry to follow the angled rack
        float xOffset = startXOffset + (i * spacing * cos(rackAngle));
        float zOffset = -1.05f + (i * spacing * sin(rackAngle));

        // Draw the test tube at the calculated position
        DrawTestTube(tablePos, tableHeight, xOffset, zOffset);
    }
}

/***********************************************************
 *  DrawTable()
 *
 *  This function draws a table, including the tabletop and
 *  four legs, at a specified position and scale. The tabletop
 *  is drawn with a wood texture and material, and the legs are
 *  positioned based on the table’s width, depth, and height.
 *  Transformations are applied to correctly position and scale
 *  the tabletop and legs in 3D space.
 *
 *  Parameters:
 *    - tablePosition (glm::vec3): The position of the table in world space.
 *    - tableScale (glm::vec3): The scale of the table, affecting the size of
 *      both the tabletop and the legs.
 ***********************************************************/
void SceneManager::DrawTable(glm::vec3 tablePosition, glm::vec3 tableScale)
{
    // Tabletop properties
    glm::vec3 scaleXYZ = glm::vec3(tableScale.x, tableScale.y, tableScale.z); // Tabletop size
    glm::vec3 positionXYZ = glm::vec3(tablePosition.x, tablePosition.y, tablePosition.z); // Table position

    // Apply transformations
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

    int textureID = FindTextureSlot("table");
    std::cout << "Table texture ID: " << textureID << std::endl;

    // Set texture
    SetShaderTexture("table");

    // Set UV scale
    SetTextureUVScale(1.0, 1.0);

    // Set shader material
    SetShaderMaterial("wood");

    // Debugging
    //SetShaderColor(1, 1, 1, 1);

    // Draw the table-top
    m_basicMeshes->DrawBoxMesh();

    /*** Draw the Table Legs ***/
    glm::vec3 legScale = glm::vec3(0.7f, 4.0f, 0.7f); // Slightly thicker legs and now taller

    // Calculate table width and depth from table scale
    float tableWidth = tableScale.x;  // Width of the tabletop
    float tableDepth = tableScale.z;  // Depth of the tabletop

    float legOffsetX = (tableWidth / 2.0f) - (legScale.x);  // Keep legs at corners
    float legOffsetZ = (tableDepth / 2.0f) - (legScale.z);  // using ratios
    float legTopY = 3.0f - (0.5f * 0.5f); // Keep the top of the legs at tabletop height
    float legBottomY = legTopY - (legScale.y / 2.0f); // Extend downward (figure out bottom instead of top)

    glm::vec3 legPositions[4] = {
        glm::vec3(tablePosition.x - legOffsetX, legBottomY, tablePosition.z - legOffsetZ), // Front-left leg
        glm::vec3(tablePosition.x + legOffsetX, legBottomY, tablePosition.z - legOffsetZ), // Front-right leg
        glm::vec3(tablePosition.x - legOffsetX, legBottomY, tablePosition.z + legOffsetZ), // Back-left leg
        glm::vec3(tablePosition.x + legOffsetX, legBottomY, tablePosition.z + legOffsetZ)  // Back-right leg
    };

    // Loop through and draw each leg
    for (int i = 0; i < 4; ++i)
    {
        // Apply transformations for each leg
        SetTransformations(
            legScale,
            0,
            0,
            0,
            legPositions[i]
        );

        // Set texture
        SetShaderTexture("tablelegs");

        // Set UV scale
        SetTextureUVScale(0.5, 1.0);

        // Set shader material
        SetShaderMaterial("wood");

        // Draw the leg mesh
        m_basicMeshes->DrawBoxMesh();
    }
}

void SceneManager::DrawFloor()
{
    // Define plane scale (match table width and thickness)
    glm::vec3 planeScale = glm::vec3(15.3f, 7.0f, 15.0f);

    // Position the plane at the front edge of the table
    glm::vec3 planePosition = glm::vec3(0.0, -1.2, -5.0);

    // Rotate the plane to face forward (assuming default plane is XY)
    float rotationAngle = 90.0f; // Rotate around the X-axis to stand up

    // Apply transformations
    SetTransformations(planeScale, 0, 0, 0, planePosition);

    SetShaderTexture("floor");

    SetTextureUVScale(2.0, 2.0);

    // Set shader material
    SetShaderMaterial("wood"); // Wood material

    // Draw the plane
    m_basicMeshes->DrawPlaneMesh();
}

void SceneManager::DrawWall()
{
    glm::vec3 planeScale = glm::vec3(15.3f, 0.1f, 10.0f);

    // Position the plane at the back of the scene (adjust the Z-coordinate to place it further back)
    glm::vec3 planePosition = glm::vec3(0.0f, 8.5f, -15.0f); // Position at the back, adjust Y as needed

    // Apply transformations
    SetTransformations(planeScale, 90, 0.0f, 0, planePosition); // Rotation applied here

    // Set color (Grey color in this case)
    //SetShaderColor(0.5f, 0.5f, 0.5f, 1.0f); // Grey color

    SetShaderTexture("wall");

    SetTextureUVScale(1.0, 1.0);

    // Set shader material
    SetShaderMaterial("wood"); // Wood material

    // Draw the plane
    m_basicMeshes->DrawPlaneMesh();

}

void SceneManager::DrawPen(glm::vec3 tablePosition, float tableHeight)
{
    // Declare the variables for the transformations
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    // Position for the pen on the table
    float tableSurfaceY = tablePosition.y + (tableHeight / 2.0f); // Tabletop surface height
    positionXYZ = glm::vec3(2.0f, tableSurfaceY + 0.1f, 3.0f); // Example position

    // Scale for the pen body (cylinder)
    scaleXYZ = glm::vec3(0.05f, 2.0f, 0.05f);  // Thin and long for the pen body

    // Set transformations for the pen body
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        90,
        positionXYZ);

    // Set texture for the pen body
    SetShaderTexture("pen");

    // Set UV Scale
    SetTextureUVScale(1.0, 1.0);

    // Set material for the pen body
    SetShaderMaterial("metal");

    // Draw the pen body (cylinder mesh)
    m_basicMeshes->DrawCylinderMesh();

    // --- Now for the pen tip (smaller cone) ---
    scaleXYZ = glm::vec3(0.05f, 0.2f, 0.05f);  // Small cone for the pen tip
    positionXYZ = glm::vec3(0.0f, tableSurfaceY + 0.10, 3.0f); // Example position

    // Set transformations for the pen tip
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        90,
        positionXYZ);

    // Set material for the pen tip
    SetShaderMaterial("metal");

    SetShaderColor(0, 0, 0, 1);

    // Draw the pen tip (cone mesh)
    m_basicMeshes->DrawConeMesh();
}

void SceneManager::DrawWaterBowl()
{
    // Declare the variables for the transformations
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    // Position for the bowl on the floor (just above the ground level)
    positionXYZ = glm::vec3(12.0f, -0.1f, -10.0f);  // Positioning the bowl at the origin (floor level)

    // Scale for the half-sphere (bowl)
    scaleXYZ = glm::vec3(0.9f, 1.0f, 0.9f);  // The shape will be like a shallow bowl

    // Set transformations for the bowl
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        180,
        positionXYZ);

    // Set texture for the bowl (half-sphere)
    SetShaderTexture("metal");

    // Set UV Scale
    SetTextureUVScale(1.0, 1.0);

    // Set material for the bowl (half-sphere)
    SetShaderMaterial("metal");

    // Draw the top half of a sphere to create a bowl
    m_basicMeshes->DrawHalfSphereMesh();

    // Add water

    // Position for the bowl on the floor
    positionXYZ = glm::vec3(12.0f, -0.2f, -10.0f);  

    // Scale for the half-sphere (bowl)
    scaleXYZ = glm::vec3(0.8f, 0.8f, 0.8f);

    // Set transformations
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        180,
        positionXYZ);

    // Set texture and material for the inkwell base
    SetShaderTexture("water");    
    SetShaderMaterial("water");
        
    // Draw the top half of a sphere
    m_basicMeshes->DrawHalfSphereMesh();
}

/**
 * @brief Draws the front, back, left, and right edge boxes for a table.
 *
 * This function draws the edges of a table using boxes for the front, back, left, and right edges.
 * Each edge box is positioned and scaled relative to the table's position and size. Textures and materials
 * are applied to each edge to give it a proper appearance. The front and back edges are slightly moved forward and backward,
 * respectively, while the left and right edges are positioned to the left and right sides of the table.
 *
 * @param tablePosition The position of the table in 3D space (x, y, z).
 * @param tableScale The scale of the table, representing its width (x), height (y), and depth (z).
 */
void SceneManager::DrawTableEdges(glm::vec3 tablePosition, glm::vec3 tableScale)
{
    /**
     * Front Edge.
     */

    // Define box scale (match table width and height, use a small thickness)
    glm::vec3 boxScale = glm::vec3(tableScale.x+0.3+0.3+.4, tableScale.y, 0.5f); 

    // Position the box at the front edge of the table
    glm::vec3 boxPosition = glm::vec3(
        tablePosition.x,                                // Centered along X
        tablePosition.y ,        // Align with top edge of tabletop
        tablePosition.z + (tableScale.z / 2.0f) + 0.25  // Move slightly forward
    );

    // Apply transformations
    SetTransformations(boxScale, 0.0f, 0, 0, boxPosition);  // No rotation needed for a box edge

    // Set texture
    SetShaderTexture("edgeH");

    // Set UV Scale
    SetTextureUVScale(1.0, 1.0);

    // Set material
    SetShaderMaterial("metal");

    // Draw the box (front edge)
    m_basicMeshes->DrawBoxMesh();

    /**
     * Back Edge.
     */
     
     // Define box scale (match table width and height, use a small thickness)
    boxScale = glm::vec3(tableScale.x + 0.3 + 0.3 + .4, tableScale.y, 0.5f);


    // Position the box at the front edge of the table
    boxPosition = glm::vec3(
        tablePosition.x,                                // Centered along X
        tablePosition.y,        // Align with top edge of tabletop
        tablePosition.z - (tableScale.z / 2.0f) - 0.25  // Move slightly forward
    );

    // Apply transformations
    SetTransformations(boxScale, 0.0f, 0, 0, boxPosition);  // No rotation needed for a box edge

    // Set texture
    SetShaderTexture("edgeH");

    // Set UV Scale
    SetTextureUVScale(5.0, 1.0);

    // Set material
    SetShaderMaterial("metal");

    // Draw the box (front edge)
    m_basicMeshes->DrawBoxMesh();

    /**
    * Left Edge.
    */
    boxScale = glm::vec3(0.5f, tableScale.y, tableScale.z);
    boxPosition = glm::vec3(
        tablePosition.x - (tableScale.x / 2.0f) - 0.25f,
        tablePosition.y,
        tablePosition.z
    );

    SetTransformations(boxScale, 0.0f, 0, 0, boxPosition);

    // Set texture
    SetShaderTexture("edgeV");

    // Set UV Scale
    SetTextureUVScale(5.0, 1.0);

    // Set material
    SetShaderMaterial("metal");

    // Draw the box (front edge)
    m_basicMeshes->DrawBoxMesh();

    /**
     * Right Edge.
     */
    boxPosition.x = tablePosition.x + (tableScale.x / 2.0f) + 0.25f;
    SetTransformations(boxScale, 0.0f, 0, 0, boxPosition);

    // Set texture
    SetShaderTexture("edgeV");

    // Set UV Scale
    SetTextureUVScale(5.0, 1.0);

    // Set material
    SetShaderMaterial("metal");

    m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  DrawTubeRack_Base()
 *
 *  This function draws the base of the test tube rack on top
 *  of the table. The base is scaled and rotated based on the
 *  specified dimensions and position relative to the table.
 *  The rack base is positioned just above the table's surface,
 *  with a small offset to ensure proper placement.
 *
 *  Parameters:
 *    - tablePosition (glm::vec3): The position of the table in world space.
 *    - tableHeight (float): The height of the table, used to calculate
 *      the correct height for the rack base.
 ***********************************************************/
void SceneManager::DrawTubeRack_Base(glm::vec3 tablePosition, float tableHeight)
{
    // Declare transformation variables
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 45.0f; // Keep original rotation
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    // TEST TUBE RACK BASE DIMENSIONS
    scaleXYZ = glm::vec3(4.0f, 0.10f, 0.8f); // Rack size

    // Compute placement based on table
    float tableSurfaceY = tablePosition.y + (tableHeight / 2.0f); // Tabletop surface height
    float rackHeight = scaleXYZ.y; // Rack base height

    // This is the calculated height for the "bottom" piece above the base
    // It is offset relative to the actual position of the base
    float rackTopOffset = 0.1;

    positionXYZ = glm::vec3(-3.0f, tableSurfaceY + (rackHeight / 2.0f) + rackTopOffset, 0.0f); // Aligned on top

    // Apply transformations
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);

    // Set texture
    SetShaderTexture("rackhorizs");

    // Set material
    SetShaderMaterial("glass");

    // Set UV scale
    SetTextureUVScale(1, 1);

    // Draw the mesh
    m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  DrawTubeRack_Top()
 *
 *  This function draws the top part of the test tube rack,
 *  positioned above the base on the table. The top piece is
 *  scaled and rotated based on the specified dimensions and
 *  position relative to the table. The top is offset vertically
 *  from the base to ensure it sits properly above it.
 *
 *  Parameters:
 *    - tablePosition (glm::vec3): The position of the table in world space.
 *    - tableHeight (float): The height of the table, used to calculate
 *      the correct height for the rack's top.
 ***********************************************************/
void SceneManager::DrawTubeRack_Top(glm::vec3 tablePosition, float tableHeight)
{
    // Declare transformation variables
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 45.0f; // Keep original rotation
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    // TEST TUBE RACK BASE DIMENSIONS
    scaleXYZ = glm::vec3(4.0f, 0.10f, 0.8f); // Rack size

    // Compute placement based on table
    float tableSurfaceY = tablePosition.y + (tableHeight / 2.0f); // Tabletop surface height
    float rackHeight = scaleXYZ.y; // Rack base height

    // This is the calculated height for the "top" piece above the base
    // It is offset relative to the actual position of the base
    float rackTopOffset = 1.05;

    positionXYZ = glm::vec3(-3.0f, tableSurfaceY + (rackHeight / 2.0f) + rackTopOffset, 0.0f); // Aligned on top

    // Apply transformations
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);

    // Set texture
    SetShaderTexture("rackhorizs");

    // Set material
    SetShaderMaterial("wood");

    // Set UV scale
    SetTextureUVScale(1, 1);

    // Draw the mesh
    m_basicMeshes->DrawBoxMesh();
}

 /***********************************************************
  *  DrawTubeRack_RightVertical()
  *
  *  This function draws the right vertical component of the
  *  test tube rack, positioned on the right side of the table.
  *  It also adds a flattened cylinder (disk-like shape) at the
  *  top of the vertical rack. The vertical piece is scaled and
  *  rotated according to the specified dimensions, and it is
  *  placed relative to the table�s surface. The flattened cylinder
  *  is positioned above the vertical rack to complete its structure.
  *
  *  A vertical wood pattern is applied to the box mesh, while
  *  a horizontal wood patttern (same pattern rotated) is applied to
  *  the cylinder mesh. This is a pretty close approximation of the wood
  *  grain following across both objects but there is a slight visual discrepancy
  *  if you zoom in where the cylinder meets the box.
  *
  *  Wood patterns without a lot of straight vertical lines help off set this effect.
  *  (Wavy wood patterns work much better)
  *
  *  Parameters:
  *    - tablePosition (glm::vec3): The position of the table in world space.
  *    - tableHeight (float): The height of the table, used to calculate
  *      the correct vertical position for the rack and cylinder.
  ***********************************************************/
void SceneManager::DrawTubeRack_RightVertical(glm::vec3 tablePosition, float tableHeight)
{
    // Declare transformation variables
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 45.0f; // Keep original rotation for perspective
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    // TEST TUBE RACK RIGHT VERTICAL DIMENSIONS
    scaleXYZ = glm::vec3(0.10f, 1.5f, 0.9f); // Rack dimensions

    // Compute placement based on table
    float tableSurfaceY = tablePosition.y + (tableHeight / 2.0f); // Tabletop surface height
    float rackHeight = scaleXYZ.y; // Rack vertical height

    // Position the rack flush with the base on the right side
    positionXYZ = glm::vec3(-1.59f, tableSurfaceY + (rackHeight / 2.0f), -1.4f); // Right vertical placement

    // Apply transformations for the rack
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);

    // Set texture
    SetShaderTexture("rackverts");

    // Set material
    SetShaderMaterial("wood");

    // Set UV scale
    SetTextureUVScale(1.0, 1.0);

    // Draw the rack mesh
    m_basicMeshes->DrawBoxMesh();

    // Adding the flattened cylinder (disk-like) to the top
    scaleXYZ = glm::vec3(0.45f, 0.1f, 0.45f); // Flatten the cylinder along the Y-axis

    // Position the flattened cylinder at the top of the rack 
    positionXYZ = glm::vec3(-1.625f, tableSurfaceY + rackHeight, -1.363f); // Place it just above the rack

    //positionXYZ = glm::vec3(1.625f, tableSurfaceY + rackHeight, -1.363f); // Place it just above the rack

    XrotationDegrees = 90.0f;
    YrotationDegrees = 135.0f;
    ZrotationDegrees = 0.0f;

    // Apply transformations for the flattened cylinder
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);

    // Set texture
    SetShaderTexture("rackhorizs");

    // Set material
    SetShaderMaterial("wood");

    // Set UV scale
    SetTextureUVScale(1.0, 1.0);

    // Draw the flattened cylinder (disk-like shape)
    m_basicMeshes->DrawCylinderMesh();
}


// Draws a small light box at the specified position in 3D space for debugging lights.
// This function will visualize the light in the scene as a small white cube.
void SceneManager::DrawLightBox(float x, float y, float z)

{
    glm::vec3 scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
    glm::vec3 positionXYZ = glm::vec3(x, y, z);

    // Apply transformations (scale, rotation, position)
    SetTransformations(
        scaleXYZ,
        0.0,
        0.0,
        0.0,
        positionXYZ);

    // Set white color for the light cube
    SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);  // White color to represent the light

    // Draw the cube mesh (light indicator)
    m_basicMeshes->DrawBoxMesh();  // Ensure this draws the cube correctly
}


/**
 * @brief Renders a left-side vertical tube rack in the scene.
 *
 *  This function draws the left vertical component of the
 *  test tube rack, positioned on the right side of the table.
 *  It also adds a flattened cylinder (disk-like shape) at the
 *  top of the vertical rack. The vertical piece is scaled and
 *  rotated according to the specified dimensions, and it is
 *  placed relative to the table�s surface. The flattened cylinder
 *  is positioned above the vertical rack to complete its structure.
 *
 *  A vertical wood pattern is applied to the box mesh, while
 *  a horizontal wood patttern (same pattern rotated) is applied to
 *  the cylinder mesh. This is a pretty close approximation of the wood
 *  grain following across both objects but there is a slight visual discrepancy
 *  if you zoom in where the cylinder meets the box.
 *
 *  Wood patterns without a lot of vertical lines help off set this effect.
 *  (Wavy wood patterns work much better)
 *
 *  Parameters:
 *    - tablePosition (glm::vec3): The position of the table in world space.
 *    - tableHeight (float): The height of the table, used to calculate
 *      the correct vertical position for the rack and cylinder.
 */
void SceneManager::DrawTubeRack_LeftVertical(glm::vec3 tablePosition, float tableHeight)
{
    // Declare transformation variables
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 45.0f; // Keep original rotation for perspective
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    // TEST TUBE RACK LEFT VERTICAL DIMENSIONS (will be same as right)
    scaleXYZ = glm::vec3(0.10f, 1.5f, 0.9f); // Rack dimensions

    // Compute placement based on table
    float tableSurfaceY = tablePosition.y + (tableHeight / 2.0f); // Tabletop surface height
    float rackHeight = scaleXYZ.y; // Rack vertical height

    // Position the rack flush with the base on the left side
    positionXYZ = glm::vec3(-4.4f, tableSurfaceY + (rackHeight / 2.0f), 1.45f); // Left vertical placement

    // Apply transformations for the rack
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);

    // Set texture
    SetShaderTexture("rackverts");

    // Set material
    SetShaderMaterial("wood");

    // Set UV scale
    SetTextureUVScale(1.0, 1.0);

    //SetShaderColor(1, 1, 0, 1);

    // Draw the rack mesh
    m_basicMeshes->DrawBoxMesh();

    // Adding the flattened cylinder (disk-like) to the top
    // The cylinder top is 0.106 on this side vs 0.10 on the other to make sure the 
    // full circle pattern is visible from the front - otherwise it makes a 'line'
    // across the front plane of the object. Just a minute barely visible increase
    // in width to make sure the pattern applies correctly.
    scaleXYZ = glm::vec3(0.45f, 0.106f, 0.45f); // Flatten the cylinder along the Y-axis

    // Position the flattened cylinder at the top of the rack 
    //positionXYZ = glm::vec3(-4.445, tableSurfaceY + rackHeight, 1.47715f);
    positionXYZ = glm::vec3(-4.436, tableSurfaceY + rackHeight, 1.485f);

    XrotationDegrees = 90.0f;
    YrotationDegrees = 135.0f;
    ZrotationDegrees = 0.0f;

    // Apply transformations for the flattened cylinder
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);

    // Set texture
    SetShaderTexture("rackhorizs");

    //SetShaderColor(1, 1, 0, 1);

    // Set material
    SetShaderMaterial("wood");

    // Set UV scale
    SetTextureUVScale(1.0, 1.0);

    // Draw the flattened cylinder (disk-like shape)
    m_basicMeshes->DrawCylinderMesh();
}

/**
 * @brief Draws a test tube with liquid, a glass top, and a torus rim.
 *
 * This function renders a test tube consisting of three main components:
 *  - **Liquid Cylinder**: Represents the liquid inside the tube.
 *  - **Glass Cylinder**: Forms the upper part of the tube.
 *  - **Torus Rim**: Encircles the top edge of the glass for realism.
 *
 * The function:
 *  - Computes the placement based on the table surface height.
 *  - Applies appropriate transformations to each component.
 *  - Uses different textures and materials for liquid and glass.
 *  - Positions the torus to simulate the thickened rim of the tube.
 *
 * @param tablePosition The position of the table in world space.
 * @param tableHeight The height of the table, used for correct tube placement.
 * @param xOffset Horizontal offset to position the test tube.
 * @param zOffset Depth offset to position the test tube.
 */

void SceneManager::DrawTestTube(glm::vec3 tablePosition, float tableHeight, float xOffset, float zOffset)
{
    // Declare the variables for the transformations
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    // Scale for the liquid part (bottom cylinder)
    scaleXYZ = glm::vec3(0.15f, 1.0f, 0.15f);  // Height is smaller for liquid part

    // Compute placement based on table
    float tableSurfaceY = tablePosition.y + (tableHeight / 2.0f); // Tabletop surface height
    float rackHeight = scaleXYZ.y; // Rack base height

    // This is the calculated height for the "bottom" piece above the base
    // It is offset relative to the actual position of the base
    float rackTopOffset = 0.1;

    // This is the offset from the bottom of the base to where the tube shoudl appear to rest
    float tubeBottomOffset = 0.1;

    // Compute position for the liquid (place it near the table surface)
    positionXYZ = glm::vec3(xOffset, tableSurfaceY + rackTopOffset + tubeBottomOffset, zOffset);

    // Set the transformations into memory to be used on the drawn meshes
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);

    // Set texture
    SetShaderTexture("liquid");
    
    // Set UV Scale
    SetTextureUVScale(1.0, 1.0);

    // Set material
    SetShaderMaterial("liquid");

    // Draw the test tube (cylinder mesh)
    m_basicMeshes->DrawCylinderMesh();

    // --- Glass top (second cylinder) ---

    // Scale for the glass part (top cylinder)
    scaleXYZ = glm::vec3(0.15f, 0.5f, 0.15f);  

    // Position the glass on top of the liquid cylinder
    positionXYZ = glm::vec3(xOffset, tableSurfaceY + rackTopOffset + tubeBottomOffset + 1.0f, zOffset); 

    // Set transformations for the glass part
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);

    // Set texture
    SetShaderTexture("glass");

    // Set UV Scale
    SetTextureUVScale(1.0, 1.0);

    // Set material
    SetShaderMaterial("glass");

    //SetShaderColor(1, 5, 15, 1);

    // Draw the glass cylinder (top part)
    m_basicMeshes->DrawCylinderMesh();

    // Positioning for the torus (around the top edge of the glass part)
    glm::vec3 torusPosition = glm::vec3(xOffset, tableSurfaceY + rackTopOffset + tubeBottomOffset + 1.0f + 0.5f, zOffset); 

    // Scale for the torus (Adjust radius to fit around the top of the tube)
    glm::vec3 torusScale = glm::vec3(0.14f, 0.14f, 0.14f);  // Larger x and z for the ring, smaller y for the thickness

    // Set transformations for the torus
    SetTransformations(
        torusScale,
        90.0f,
        YrotationDegrees,
        ZrotationDegrees,
        torusPosition);
      
    // Set texture
    SetShaderTexture("glass");

    // Set UV Scale
    SetTextureUVScale(1.0, 1.0);

    // Set material
    SetShaderMaterial("glass");

    // Draw the torus
    m_basicMeshes->DrawTorusMesh();  // Assuming a function exists to draw the torus mesh
}

/**
 * @brief Simulates flickering candlelight in the scene.
 *
 * This function updates the properties of a point light to create a natural flickering effect,
 * mimicking candlelight behavior. It is intented to be a soft light that does not dominiate the scene,
 * but rather complements it. The viewer may not notice it immediately but over time it will be obvious.
 * 
 * It uses a combination of:
 *  - Randomized intensity variations for subtle and occasional large flickers.
 *  - Smooth transitions between flicker states using linear interpolation.
 *  - Dynamic adjustment of light properties (ambient, diffuse, and specular) based on flicker intensity.
 *  - A timed update mechanism to control flicker frequency.
 *
 * The function ensures that light flickering appears natural by:
 *  - Randomly selecting a new intensity at regular intervals.
 *  - Occasionally introducing larger, sudden dips in brightness to simulate environmental effects like wind.
 *  - Applying flicker to all relevant lighting parameters.
 *
 * @note The function maintains static state for flicker timing and intensity control.
 */
void SceneManager::SetFlickeringLights()
{
    float tableSurfaceY = m_tableScale.y;
    float baseHeight = 0.3;
    float candleHeight = 2.0;

    // Static variables for flickering control
    static auto lastFlickerTime = std::chrono::steady_clock::now();
    static float nextFlickerDelay = 0.1f;  

    // Persistent flicker intensity 
    static float currentFlicker = 1.0f;
    static float targetFlicker = 1.0f;

    // Seed RNG once
    static bool seeded = false;
    if (!seeded) {
        std::srand(static_cast<unsigned int>(std::time(0)));
        seeded = true;
    }

    // Get elapsed time since last flicker update
    auto now = std::chrono::steady_clock::now();
    float elapsedTime = std::chrono::duration<float>(now - lastFlickerTime).count();

    if (elapsedTime >= nextFlickerDelay) {

        // Set a new random flicker intensity (small random shifts)
        targetFlicker = 0.85f + (static_cast<float>(std::rand() % 30) / 100.0f);  // Between 0.85 - 1.15

        // Occasionally, add a big flicker (simulate a wind gust / window might be open, etc.)
        if (std::rand() % 10 == 0) {
            targetFlicker *= 0.6f + (static_cast<float>(std::rand() % 50) / 100.0f);  // Drop suddenly
        }

        // Set next flicker delay (small changes quickly, bigger flickers occasionally)
        nextFlickerDelay = 0.05f + (static_cast<float>(std::rand() % 15) / 100.0f);  // 0.05 - 0.2 sec

        lastFlickerTime = now;
    }

    // Smooth transition using linear interpolation (lerp)

    float smoothFactor = 0.1f;  // Controls smoothness
    currentFlicker += (targetFlicker - currentFlicker) * smoothFactor;

    // Set position of the point light (top of the candle)
    m_pShaderManager->setVec3Value("pointLights[0].position", 4.0f, 8.0, 1.0f);

    // Apply flicker to light properties
// Increase the light strength without making it too intense
    m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.2f * currentFlicker, 0.1f * currentFlicker, 0.04f * currentFlicker);
    m_pShaderManager->setVec3Value("pointLights[0].diffuse", 1.2f * currentFlicker, 1.1f * currentFlicker, 0.4f * currentFlicker); 
    m_pShaderManager->setVec3Value("pointLights[0].specular", 1.0f * currentFlicker, 0.9f * currentFlicker, 0.4f * currentFlicker);


    // Set point light attenuation
    m_pShaderManager->setFloatValue("pointLights[0].constantAttenuation", 1.0f);
    m_pShaderManager->setFloatValue("pointLights[0].linearAttenuation", 0.2f);
    m_pShaderManager->setFloatValue("pointLights[0].quadraticAttenuation", 0.03f);

    // Enable point light
    m_pShaderManager->setBoolValue("pointLights[0].bActive", true);
}

/**
 * @brief Draws a candle with a base and a flame on a table.
 *
 * This function renders a candle composed of three main parts:
 *  - A **tapered base** (truncated cone) to provide stability.
 *  - A **cylindrical candle body** to represent the wax.
 *  - A **small cylinder** at the top to simulate the flame.
 *
 * The function applies transformations and materials to achieve a realistic appearance:
 *  - Positions the candle and base on the given table surface.
 *  - Uses distinct textures and materials for the base (metal), candle (wax), and flame.
 *  - Adjusts UV scaling to ensure proper texture mapping.
 *  - Utilizes transformation functions to position, scale, and rotate each component.
 *
 * @param tablePosition The position of the table in world space.
 * @param tableHeight The height of the table, used to compute the correct candle placement.
 */

void SceneManager::DrawCandle(glm::vec3 tablePosition, float tableHeight)
{
    // Local candle and base dimensions
    float candleHeight = 2.0f; // Height of the candle
    float candleRadius = 0.1f; // Radius of the candle
    float baseHeight = 0.3f;   // Height of the candle's base
    float baseRadius = 0.45f;  // Radius of the candle's base

    // Declare transformation variables
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    // Compute table surface height
    float tableSurfaceY = tablePosition.y + (tableHeight / 2.0f);

    // Set position for the candle base
    positionXYZ = glm::vec3(4.0f, tableSurfaceY + (baseHeight / 2.0f), 0.0f); // Centered on the table

    // Tapered base of the candle (a truncated cone)
    scaleXYZ = glm::vec3(baseRadius, baseHeight, baseRadius); // Base dimensions

    // Apply transformations for the base
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

    // Set texture
    SetShaderTexture("metal");

    // Set UV Scale
    SetTextureUVScale(1.0, 1.0);

    // Set material
    SetShaderMaterial("metal");

    // Draw the base as a tapered cylinder (truncated cone)
    m_basicMeshes->DrawTaperedCylinderMesh();

    // Set position for the candle itself
    positionXYZ = glm::vec3(4.0f, tableSurfaceY + baseHeight, 0.0f); // Above the base

    // Regular candle shape (a cylinder)
    scaleXYZ = glm::vec3(candleRadius, candleHeight, candleRadius); // Candle dimensions

    // Apply transformations for the candle
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

    //SetShaderColor(1, 1, 0, 1);  // Bright color for the candle (yellow)

    // Set texture
    SetShaderTexture("candle");

    // Set UV Scale
    SetTextureUVScale(5.0, 1.0);

    // Set material
    SetShaderMaterial("wax");

    // Draw the candle as a regular cylinder
    m_basicMeshes->DrawCylinderMesh();

    // Draw a small cylinder on top of the candle to represent the flame
    positionXYZ = glm::vec3(4.0f, tableSurfaceY + baseHeight + candleHeight, 0.0f); // Top of the candle
    scaleXYZ = glm::vec3(0.03f, 0.2f, 0.05f); // Small cylinder dimensions for the flame

    // Apply transformations for the flame
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

    SetShaderColor(1, 1, 0, 1);  // Bright yellow color for the flame
    m_basicMeshes->DrawCylinderMesh(); // Draw the small cylinder as the flame
}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
    CreateGLTexture(
        "textures/tabletop.jpg",
        "table");

    CreateGLTexture(
        "textures/glass.png",
        "glass");

    CreateGLTexture(
        "textures/liquid.png",
        "liquid");

    CreateGLTexture(
        "textures/metal.png",
        "metal");

    CreateGLTexture(
        "textures/candle.png",
        "candle");

    // wood pattern with grain aligned vertically
    // used for vertical supports of the test tube rack
    CreateGLTexture(
        "textures/woodv.jpg",
        "rackverts");

    // wood pattern with grain aligned vertically
    // used for the rounded tops of the test tube rack vertical supports
    CreateGLTexture(
        "textures/woodh.jpg",
        "rackhorizs");

    // oak wood pattern with grain aligned vertically
    // used for the table legs
    CreateGLTexture(
        "textures/oak.jpg",
        "tablelegs");

    CreateGLTexture(
        "textures/wall.png",
        "wall");

    CreateGLTexture(
        "textures/floor.jpg",
        "floor");

    CreateGLTexture(
        "textures/edgeH.png",
        "edgeH");

    CreateGLTexture(
        "textures/edgeV.png",
        "edgeV");

    CreateGLTexture(
        "textures/paper.png",
        "paper");

    CreateGLTexture(
        "textures/blackglass.png",
        "blackglass");

    CreateGLTexture(
        "textures/pen.png",
        "pen");

    CreateGLTexture(
        "textures/water.png",
        "water");

    // after the texture image data is loaded into memory, the
    // loaded textures need to be bound to texture slots - there
    // are a total of 16 available slots for scene textures
    BindGLTextures();
}

/**
 * @brief Draws a beaker consisting of two parts: liquid and glass.
 *
 * This function handles the drawing of the beaker by first rendering the liquid (a cylinder),
 * followed by the glass container (another cylinder) that encloses the liquid. Transformations
 * are applied to correctly position, scale, and rotate the liquid and glass. Textures and materials
 * are also set to differentiate between the liquid and glass parts.
 *
 * @param tablePosition The position of the table on which the beaker will sit.
 * @param tableHeight The height of the table, used to position the beaker correctly above it.
 */
void SceneManager::DrawBeaker(glm::vec3 tablePosition, float tableHeight)
{
    // Declare the variables for the transformations
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    // Scale for the liquid part (bottom cylinder)
    scaleXYZ = glm::vec3(0.6f, 1.5f, 0.63f);  

    // Compute placement based on table
    float tableSurfaceY = tablePosition.y + (tableHeight / 2.0f); 
    float beakerBaseOffset = 0.05f; 

    // Compute position for the liquid (inside the beaker)
    positionXYZ = glm::vec3(-5, tableSurfaceY + beakerBaseOffset + 0.25f, -2);

    // Set transformations for the liquid
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);

    // Set texture
    SetShaderTexture("liquid");

    // Set UV Scale
    SetTextureUVScale(1.0, 1.0);

    // Set material
    SetShaderMaterial("liquid");

    // Draw the liquid part (cylinder mesh)
    m_basicMeshes->DrawCylinderMesh();

    // --- Now for the glass container (outer cylinder) ---

    // Scale for the glass part
    scaleXYZ = glm::vec3(0.65f, 2.0f, 0.65f);  

    // Position the glass to enclose the liquid
    positionXYZ = glm::vec3(-5, tableSurfaceY + beakerBaseOffset + 0.25f, -2);

    // Set transformations for the glass part
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);

    // Set texture
    SetShaderTexture("glass");

    // Set UV Scale
    SetTextureUVScale(1.0, 1.0);

    // Set material
    SetShaderMaterial("glass");

    // Draw the beaker's outer glass
    m_basicMeshes->DrawCylinderMesh();

}

void SceneManager::DrawInkwell(glm::vec3 tablePosition, float tableHeight)
{
    float inkwellHeight = 0.8f;  // Height of the inkwell base (box)
    float inkwellRadius = 0.2f;  // Radius of the torus
    float inkwellWidth = 0.8f;   // Width of the box (base)
    float inkwellLength = 0.8f;  // Length of the box (base)
    float torusThickness = 0.05f;  // Thickness of the torus
    float cylinderHeight = 0.1f;   // Height of the flattened cylinder

    // Declare transformation variables
    glm::vec3 scaleXYZ;
    glm::vec3 positionXYZ;

    // Compute table surface height
    float tableSurfaceY = tablePosition.y + (tableHeight / 2.0f);

    // **Base of the inkwell (box)**
    positionXYZ = glm::vec3(tablePosition.x, tableSurfaceY + 0.1f, tablePosition.z - 1.5); 
    scaleXYZ = glm::vec3(inkwellWidth, inkwellHeight, inkwellLength); 

    // Apply transformations
    SetTransformations(scaleXYZ, 0.0f, 15.0f, 0.0f, positionXYZ);

    // Set texture and material for the inkwell base
    SetShaderTexture("blackglass");  
    SetShaderMaterial("glass");

    // Draw the inkwell base as a box
    m_basicMeshes->DrawBoxMesh();

    // **Flattened cylinder between the inkwell box and the torus (connector)**
    positionXYZ = glm::vec3(tablePosition.x, tableSurfaceY + inkwellHeight + cylinderHeight / 2.0f - 0.34, tablePosition.z - 1.5);  
    scaleXYZ = glm::vec3(inkwellRadius, cylinderHeight, inkwellRadius);  

    // Apply transformations for the flattened cylinder
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

    // Set texture and material for the cylinder
    SetShaderColor(0, 0, 0, 1);
    SetShaderMaterial("metal");

    // Draw the flattened cylinder
    m_basicMeshes->DrawCylinderMesh();

    // **Torus on top of the inkwell (the opening)**
    positionXYZ = glm::vec3(tablePosition.x, tableSurfaceY + inkwellHeight + cylinderHeight + torusThickness - 0.34, tablePosition.z - 1.5);  
    scaleXYZ = glm::vec3(inkwellRadius, inkwellRadius, inkwellRadius); 

    // Apply transformations for the torus
    SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);

    // Set texture and material for the torus
    SetShaderTexture("metal");  
    SetShaderMaterial("metal");

    // Draw the torus on top of the inkwell
    m_basicMeshes->DrawTorusMesh();
}

/**
 * @brief Draws an inkwell consisting of a base, a flattened cylinder, and a torus.
 *
 * This function handles the drawing of an inkwell by rendering three components:
 * 1. A box representing the base of the inkwell.
 * 2. A flattened cylinder acting as a connector between the base and the torus.
 * 3. A torus representing the opening of the inkwell.
 *
 * The components are scaled, positioned, and rotated using transformations. Textures and materials
 * are applied to distinguish the different parts of the inkwell (base, connector, and opening).
 *
 * @param tablePosition The position of the table on which the inkwell will sit.
 * @param tableHeight The height of the table, used to position the inkwell correctly above it.
 */
void SceneManager::DrawPapers(glm::vec3 tablePosition, float tableHeight)
{
    // Declare the variables for the transformations
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    // Scale for the paper (flat plane)
    scaleXYZ = glm::vec3(1.2f, 0.01f, 1.6f); 

    // Compute placement based on table
    float tableSurfaceY = tablePosition.y + (tableHeight / 2.0f); 
    float paperOffset = 0.05f;

    // Position for the first paper (slightly off to the side)
    positionXYZ = glm::vec3(1, tableSurfaceY + paperOffset, 2);

    // Set transformations for the first paper
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        25,
        ZrotationDegrees,
        positionXYZ);

    // Set texture for the paper
    SetShaderTexture("paper");

    // Set UV Scale
    SetTextureUVScale(1.0, 1.0);

    // Set material
    SetShaderMaterial("metal");

    // Draw the first paper (plane mesh)
    m_basicMeshes->DrawPlaneMesh();

    return;

    // Position for the second paper (slightly offset from the first one)
    positionXYZ = glm::vec3(1, tableSurfaceY + paperOffset, -1);  

    // Set transformations for the second paper
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);

    // Set texture for the second paper
    SetShaderTexture("paper");

    // Set UV Scale
    SetTextureUVScale(1.0, 1.0);

    // Set material
    SetShaderMaterial("paper");

    // Draw the second paper (plane mesh)
    m_basicMeshes->DrawPlaneMesh();
}

/**
 * @brief Draws a wine glass consisting of a stem, bowl, and base.
 *
 * This function handles the drawing of a wine glass by rendering the following components:
 * 1. A stem (a tapered cylinder).
 * 2. A bowl (a larger tapered cylinder) that sits atop the stem and holds the wine.
 * 3. A flat base (a small cylinder) that supports the stem.
 *
 * The components are scaled, positioned, and rotated using transformations. Textures and materials
 * are applied to distinguish between the different parts of the glass (stem, bowl, and base).
 *
 * @param tablePosition The position of the table on which the wine glass will sit.
 * @param tableHeight The height of the table, used to position the glass correctly above it.
 */
void SceneManager::DrawWineGlass(glm::vec3 tablePosition, float tableHeight)
{
    // Declare the variables for the transformations
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    // Scale for the wine glass stem and base (tapered cylinder)
    scaleXYZ = glm::vec3(0.1f, 0.8f, 0.1f);
    float tableSurfaceY = tablePosition.y + (tableHeight / 2.0f);
    float glassBaseOffset = 0.85f; 

    // Position for the stem (slightly above the table)
    positionXYZ = glm::vec3(4, tableSurfaceY+0.08, 3);

    // Set transformations for the wine glass stem
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);

    // Set texture for the glass (stem)
    SetShaderTexture("glass");

    // Set UV Scale
    SetTextureUVScale(1.0, 1.0);

    // Set material for the glass (stem)
    SetShaderMaterial("glass");

    // Draw the stem of the glass (tapered cylinder mesh)
    m_basicMeshes->DrawTaperedCylinderMesh();

    // Draw Wine
    scaleXYZ = glm::vec3(0.38f, 0.6f, 0.38f);  
    positionXYZ = glm::vec3(4, tableSurfaceY + glassBaseOffset + 0.81f, 3); 

    // Set transformations for the bowl of the glass
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        180,
        positionXYZ);

    // Set texture for the glass (bowl)
    SetShaderTexture("glass");

    SetShaderColor(0.5f, 0.0f, 0.13f, 0.9f); 

    // Set material for the glass (bowl)
    SetShaderMaterial("glass");

    // Draw the bowl of the glass (larger tapered cylinder mesh)
    m_basicMeshes->DrawTaperedCylinderMesh();

    // --- wine glass bowl (larger tapered cylinder) ---
    scaleXYZ = glm::vec3(0.4f, 0.8f, 0.4f); 
    positionXYZ = glm::vec3(4, tableSurfaceY + glassBaseOffset + 0.8f, 3); 

    // Set transformations for the bowl of the glass
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        180,
        positionXYZ);

    // Set texture for the glass (bowl)
    SetShaderTexture("glass");

    // Set UV Scale
    SetTextureUVScale(1.0, 1.0);
    
    // Set material for the glass (bowl)
    SetShaderMaterial("glass");

    // Draw the bowl of the glass (larger tapered cylinder mesh)
    m_basicMeshes->DrawTaperedCylinderMesh();

    // --- Draw the flat base of the wine glass ---
    scaleXYZ = glm::vec3(0.4f, 0.04f, 0.4f); 
    positionXYZ = glm::vec3(4, tableSurfaceY+0.01, 3); 

    // Set transformations for the base
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);

    // Set texture for the base (glass texture)
    SetShaderTexture("glass");

    // Set UV Scale
    SetTextureUVScale(1.0, 1.0);

    // Set material for the base (glass)
    SetShaderMaterial("glass");

    // Draw the flat base (cylinder mesh)
    m_basicMeshes->DrawCylinderMesh();

}


void SceneManager::DefineObjectMaterials()
{
    // Metal material
    OBJECT_MATERIAL metalMaterial;
    metalMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f);
    metalMaterial.specularColor = glm::vec3(0.7f, 0.7f, 0.6f);
    metalMaterial.shininess = 52.0;
    metalMaterial.tag = "metal";
    m_objectMaterials.push_back(metalMaterial);

    // Glass material
    OBJECT_MATERIAL glassMaterial;
    glassMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
    glassMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
    glassMaterial.shininess = 95.0;
    glassMaterial.tag = "glass";
    m_objectMaterials.push_back(glassMaterial);

    // Liquid material
    OBJECT_MATERIAL liquidMaterial;
    liquidMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
    liquidMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
    liquidMaterial.shininess = 95.0;
    liquidMaterial.tag = "liquid";
    m_objectMaterials.push_back(liquidMaterial);

    // Wood material
    OBJECT_MATERIAL woodMaterial;
    woodMaterial.diffuseColor = glm::vec3(0.55f, 0.27f, 0.07f); 
    woodMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);  
    woodMaterial.shininess = 1.0f; 
    woodMaterial.tag = "wood";
    m_objectMaterials.push_back(woodMaterial);

    // Wood material
    OBJECT_MATERIAL waxMaterial;
    waxMaterial.diffuseColor = glm::vec3(1.2f, 1.2f, 1.2f);
    waxMaterial.specularColor = glm::vec3(4.1f, 4.1f, 4.1f);
    waxMaterial.shininess = 95.0;
    waxMaterial.tag = "wax";
    m_objectMaterials.push_back(waxMaterial);

    // Water material
    OBJECT_MATERIAL waterMaterial;
    waterMaterial.diffuseColor = glm::vec3(0.1f, 0.1f, 0.2f);
    waterMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
    waterMaterial.shininess = 25.0f; 
    waterMaterial.tag = "water";
    m_objectMaterials.push_back(waterMaterial);
}

void SceneManager::AddSceneLights()
{
    // Enable lighting in the shader
    m_pShaderManager->setBoolValue(g_UseLightingName, true);

    // This light simulates natural light scattering with a very subtle effect
    // This could be the moonlight coming in through the window for example
    m_pShaderManager->setVec3Value("globalAmbientColor", glm::vec3(0.05f, 0.06f, 0.09f));
    m_pShaderManager->setVec3Value("directionalLight.direction", -0.1f, -1.0f, -0.2f);   
    m_pShaderManager->setVec3Value("directionalLight.ambient", 0.2f, 0.2f, 0.2f);        
    m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.1f, 0.1f, 0.1f);        
    m_pShaderManager->setVec3Value("directionalLight.specular", 0.3f, 0.3f, 0.3f);       
    m_pShaderManager->setBoolValue("directionalLight.bActive", true);  

    // point light 2
    m_pShaderManager->setVec3Value("pointLights[1].position", 4.0f, 8.0f, 0.0f);
    m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.05f, 0.05f, 0.05f);
    m_pShaderManager->setVec3Value("pointLights[1].diffuse", 0.3f, 0.3f, 0.3f);
    m_pShaderManager->setVec3Value("pointLights[1].specular", 0.1f, 0.1f, 0.1f);
    m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

    // point light 2 - Pale Moonlight
    m_pShaderManager->setVec3Value("pointLights[2].position", 0.0f, 12.0f, -12.0f);
    m_pShaderManager->setVec3Value("pointLights[2].ambient", 0.4f, 0.4f, 0.2f);  
    m_pShaderManager->setVec3Value("pointLights[2].diffuse", 0.3f, 0.3f, 0.5f); 
    m_pShaderManager->setVec3Value("pointLights[2].specular", 0.05f, 0.05f, 0.1f); 
    m_pShaderManager->setBoolValue("pointLights[2].bActive", true);
    
    // Light on wall to right of scene
    m_pShaderManager->setVec3Value("pointLights[3].position", 15.0f, 25.0f, -15.0f);
    m_pShaderManager->setVec3Value("pointLights[3].ambient", 0.2f, 0.2f, 0.1f);     
    m_pShaderManager->setVec3Value("pointLights[3].diffuse", 0.3f, 0.3f, 0.3f);     
    m_pShaderManager->setVec3Value("pointLights[3].specular", 0.1f, 0.1f, 0.1f);  
    m_pShaderManager->setBoolValue("pointLights[3].bActive", true);  
    
}